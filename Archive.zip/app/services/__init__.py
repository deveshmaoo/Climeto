# HRMSV3_optimized/app/services/__init__.py
"""
Services package for business logic.
This layer sits between the routes and models, handling all business logic.
"""